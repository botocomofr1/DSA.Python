package com.gildedrose.Inventory;

import com.gildedrose.model.Item;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

/**
 * This is the inventory interface to retrieve available items
 */
public interface InventoryAccessor {

    public List<Item> loadInventory() throws FileNotFoundException, IOException;


}

package com.gildedrose.Controller;

import com.gildedrose.SurgePricing.PriceSurger;
import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


/*
This is a buy controller. It returns sucess or no item no longer available message
If it is not value requests or execption, BAD_REQUEST will be sent
 */
@Controller
@RequestMapping("/buy")
public class BuyItemController {

    @Autowired
    @Qualifier("simplesurger")
    private PriceSurger priceSurger;

    @RequestMapping(method = RequestMethod.PUT, produces = "application/json")
    public
    @ResponseBody
    ResponseEntity<?> buyItem(HttpServletRequest request, @RequestParam(value = "name", required = true) String name) {
        try {
            String buyMsg = priceSurger.buyItem(name.trim());
            return new ResponseEntity(buyMsg, HttpStatus.OK);
        } catch (Throwable throwable) {
            return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
        }

    }
}

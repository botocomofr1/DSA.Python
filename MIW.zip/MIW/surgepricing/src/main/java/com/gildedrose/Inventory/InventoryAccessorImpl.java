package com.gildedrose.Inventory;

import com.gildedrose.model.Item;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;


/**
 * This is a file base inventory accessor. The file path is configurable and it takes the value to set the inventory src
 */
@Service("inventoryaccessor")
public class InventoryAccessorImpl implements InventoryAccessor {


    String inventorySrc;

    private String ResolveFilePath() throws FileNotFoundException {
        Path currentRelativePath = Paths.get("");
        Path filepath = currentRelativePath.resolve(getInventorySrc());
        File f = filepath.toFile();
        if (f.exists() && !f.isDirectory()) {
            return f.getAbsolutePath();
        } else {
            throw new FileNotFoundException(getInventorySrc() + " Not Found");
        }
    }

    @Override
    public List<Item> loadInventory() throws IOException, FileNotFoundException {

        List<Item> result = new ArrayList<Item>();
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        try {
            String fullPath = ResolveFilePath();
            br = new BufferedReader(new FileReader(fullPath));
            while ((line = br.readLine()) != null) {
                String[] items = line.split(cvsSplitBy);
                Item item = new Item(
                        items[0], items[1], new BigDecimal(items[2]));
                result.add(item);
            }


        } catch (FileNotFoundException ex) {
            throw ex;
        } catch (IOException ioex) {
            throw ioex;
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }

    public String getInventorySrc() {
        return inventorySrc;
    }

    @Value("${inventory.filepath}")
    public void setInventorySrc(String inventorySrc) {
        this.inventorySrc = inventorySrc;
    }


}

package com.gildedrose.SurgePricing;

import com.gildedrose.Inventory.InventoryAccessor;
import com.gildedrose.model.Item;
import com.gildedrose.model.ProgressPriceItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;

/**
 * This simple price surger will load the items in the memory.
 * Progress Price Item will be checked to update the price as being viewed.
 * Price will be updated once within single viewing window if it is being viewd by more than configurable viewing limit.
 */
@Service("simplesurger")
public class SimplePriceSurger implements PriceSurger {

    AtomicBoolean loaded;
    // These are configurable values to control the price increase, view count limit, hour limit.
    long hourLimit;
    BigDecimal increaseBy;
    int viewCountLimit;
    // This is psudo cache items holding in memory
    ArrayList<ProgressPriceItem> cachedItems = new ArrayList<ProgressPriceItem>();
    private InventoryAccessor inventoryAccessor;

    public SimplePriceSurger() {
        loaded = new AtomicBoolean();
    }

    @Override
    public ArrayList<ProgressPriceItem> retrieveItems() throws Exception {

        if (loaded.get()) {
            for (ProgressPriceItem pitem : cachedItems) {
                pitem.view();
            }
            return cachedItems;
        }

        try {
            for (Item item : inventoryAccessor.loadInventory()) {
                ProgressPriceItem pitem = new ProgressPriceItem(item.name, item.description, item.price, getViewCountLimit(), getHourLimit(), getIncreaseBy());
                cachedItems.add(pitem.view());
            }
            loaded.set(true);
            return cachedItems;
        } catch (Exception ex) {

            throw new Exception("Unable to retrieve items", ex);
        }
    }

    // The buy action is synchronized, it is to guarantee to secure the item and no change in price.
    // In large scale system, the lock could be performed in zooker or other type of centralized server.
    @Override
    synchronized public String buyItem(String name) {
        Predicate<ProgressPriceItem> item = p -> p.name.equals(name);
        if (!loaded.get())
            return "Please list the items first";

        if (cachedItems.removeIf(item)) {
            return "You bought this item " + name;
        } else {
            return "Item " + name + " no longer available";
        }

    }

    public InventoryAccessor getInventoryAccessor() {
        return inventoryAccessor;
    }

    @Autowired
    public void setInventoryAccessor(InventoryAccessor inventoryAccessor) {
        this.inventoryAccessor = inventoryAccessor;
    }


    public BigDecimal getIncreaseBy() {
        return increaseBy;
    }

    @Value("${item.increaseBy}")
    public void setIncreaseBy(BigDecimal increaseBy) {
        this.increaseBy = increaseBy;
    }

    public int getViewCountLimit() {
        return viewCountLimit;
    }

    @Value("${item.viewCountLimit}")
    public void setViewCountLimit(int viewCountLimit) {
        this.viewCountLimit = viewCountLimit;
    }

    public long getHourLimit() {
        return hourLimit;
    }

    @Value("${item.hourLimit}")
    public void setHourLimit(long hourLimit) {
        this.hourLimit = hourLimit;
    }

}

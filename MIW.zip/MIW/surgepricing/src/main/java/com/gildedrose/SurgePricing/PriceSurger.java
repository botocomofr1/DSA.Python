package com.gildedrose.SurgePricing;

import com.gildedrose.model.ProgressPriceItem;

import java.util.ArrayList;

/**
 * PriceSurge is the interface to support List and Buy items.
 */
public interface PriceSurger {
    public ArrayList<ProgressPriceItem> retrieveItems() throws Exception;

    public String buyItem(String name);

}

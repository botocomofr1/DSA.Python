package com.gildedrose.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.time.LocalTime;

/**
 * This is a progress price item.
 * Each progress price item has viewCount, viewing window.
 * Within the viewing window, if the view count reach configurable view count limit, it will increase the prices by increaseBy value.
 * The price only increases once within a viewing window.
 * View Count is reset every viewing window.
 */
public class ProgressPriceItem extends Item {

    private int viewCountLimit;
    private long hourLimit;
    private BigDecimal increaseBy;

    private LocalTime viewingWindowBegin;
    private LocalTime viewingWindowEnd;
    private int viewCount = 0;
    private boolean increasedForThisPeriod;

    public ProgressPriceItem(String name, String description, BigDecimal price,
                             int viewCountLimit, long hourLimit, BigDecimal increaseBy) {
        super(name, description, price);

        this.viewCountLimit = viewCountLimit;
        this.hourLimit = hourLimit;
        this.increaseBy = increaseBy;

        viewingWindowBegin = LocalTime.now();
        viewingWindowEnd = viewingWindowBegin.plusHours(hourLimit);
        increasedForThisPeriod = false;
    }

    public ProgressPriceItem view() {
        UpdatePrice();
        return this;
    }

    // Assume there might multiple users/threads view the items simultaneously.
    // Synchonrize method to guarantee update.
    // In large scale system, synchronized will be done by the distributed respository. (such as NoSQL)
    synchronized protected void UpdatePrice() {
        viewCount++;
        LocalTime currentTime = LocalTime.now();
        if (currentTime.isAfter(viewingWindowBegin)
                && currentTime.isBefore(viewingWindowEnd)
                && viewCount > getViewCountLimit()
                && !increasedForThisPeriod) {
            price = price.multiply(getIncreaseBy());
            increasedForThisPeriod = true;
        } else if (currentTime.isAfter(viewingWindowEnd)) {
            // new period
            viewCount = 0;
            viewingWindowBegin = currentTime;
            viewingWindowEnd = viewingWindowBegin.plusHours(hourLimit);
            increasedForThisPeriod = false;
        }
    }

    @JsonIgnore
    public BigDecimal getIncreaseBy() {
        return increaseBy;
    }


    public void setIncreaseBy(BigDecimal increaseBy) {
        this.increaseBy = increaseBy;
    }

    @JsonIgnore
    public int getViewCountLimit() {
        return viewCountLimit;
    }


    public void setViewCountLimit(int viewCountLimit) {
        this.viewCountLimit = viewCountLimit;
    }

    @JsonIgnore
    public long getHourLimit() {
        return hourLimit;
    }


    public void setHourLimit(long hourLimit) {
        this.hourLimit = hourLimit;
    }
}

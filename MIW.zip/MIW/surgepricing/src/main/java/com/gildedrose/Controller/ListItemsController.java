package com.gildedrose.Controller;

import com.gildedrose.SurgePricing.PriceSurger;
import com.gildedrose.model.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;

/**
 * This is list controller. It list the available items. If any exception, BAD_REQUEST will be sent.
 */
@Controller
@RequestMapping("/list")
public class ListItemsController {

    @Autowired
    @Qualifier("simplesurger")
    private PriceSurger priceSurger;

    @RequestMapping(method = RequestMethod.GET, produces = "application/json")
    public
    @ResponseBody
    ResponseEntity<?> getInventory() {
        ArrayList<Item> inventory = new ArrayList<>();
        try {

            for (Item item : priceSurger.retrieveItems()) {
                inventory.add(item);
            }
            return new ResponseEntity(inventory, HttpStatus.OK);
        } catch (Exception ex) {

            return new ResponseEntity<String>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }

    }

}

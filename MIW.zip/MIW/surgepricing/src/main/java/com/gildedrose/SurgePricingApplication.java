package com.gildedrose;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SurgePricingApplication {

    public static void main(String[] args) {

        SpringApplication.run(SurgePricingApplication.class, args);
    }
}








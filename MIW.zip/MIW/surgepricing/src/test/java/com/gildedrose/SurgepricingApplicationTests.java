package com.gildedrose;

import com.gildedrose.Controller.BuyItemController;
import com.gildedrose.Controller.ListItemsController;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {com.gildedrose.AppConfig.class})
@TestPropertySource("classpath:test.properties")
@SpringBootTest
public class SurgepricingApplicationTests {

    final String base_url = "http://localhost:8080";
    @Autowired
    private ListItemsController listController;

    @Autowired
    private BuyItemController buyController;

    private MockMvc mockMvc;

    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(listController).build();
    }

    @Test
    public void testListController() throws Exception {

        this.mockMvc.perform(get("/list")).andDo(print()).andExpect(status().isOk())
                .andExpect(content().string(containsString("A")));
    }

    @Test
    public void contextLoads() {
        assertThat(listController).isNotNull();
        assertThat(buyController).isNotNull();
    }

}

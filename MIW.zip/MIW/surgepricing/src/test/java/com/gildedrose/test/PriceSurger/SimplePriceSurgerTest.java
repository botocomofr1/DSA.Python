package com.gildedrose.test.PriceSurger;

import com.gildedrose.SurgePricing.PriceSurger;
import com.gildedrose.model.ProgressPriceItem;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Created by envy on 2/9/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {com.gildedrose.AppConfig.class})
@TestPropertySource("classpath:test.properties")

public class SimplePriceSurgerTest {


    @Autowired
    @Qualifier("simplesurger")
    private PriceSurger priceSurger;

    @Test
    public void getPriceSurger() throws Exception {
        Assert.assertNotNull(priceSurger);

    }

    @Test
    public void retrieveItems() throws Exception {
        Assert.assertNotNull(priceSurger);
        ArrayList<ProgressPriceItem> items = priceSurger.retrieveItems();
        Assert.assertTrue(items.size() > 0 && items.size() < 10);
    }


    @Test
    public void retrieveItems11Times() throws Exception {
        Assert.assertNotNull(priceSurger);
        ArrayList<ProgressPriceItem> items = priceSurger.retrieveItems();
        Thread.sleep(20);
        ProgressPriceItem firstItem = items.get(0);
        BigDecimal beginPrice = new BigDecimal(0);
        BigDecimal endPrice = new BigDecimal(0);
        for (int i = 0; i < 11; i++) {
            ProgressPriceItem eachView = firstItem.view();
            Thread.sleep(100);

            if (i == 0)
                beginPrice = eachView.price;
            if (i == 10)
                endPrice = eachView.price;
        }
        Assert.assertEquals(1, endPrice.compareTo(beginPrice));

    }

    @Test
    public void buyItem() throws Exception {

        Assert.assertNotNull(priceSurger);
        ArrayList<ProgressPriceItem> items = priceSurger.retrieveItems();
        String result = priceSurger.buyItem("E");
        Assert.assertTrue(result.contains("You bought this item"));
        String resultMsg = priceSurger.buyItem("E");
        Assert.assertTrue(resultMsg.contains("no longer available"));
    }


}
package com.gildedrose.test.Inventory;

import com.gildedrose.Inventory.InventoryAccessor;
import com.gildedrose.model.Item;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/**
 * Created by envy on 2/9/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {com.gildedrose.AppConfig.class})
@TestPropertySource("classpath:test.properties")
public class InventoryAccessorImplTest {


    @Autowired
    @Qualifier("inventoryaccessor")
    private InventoryAccessor inventoryAccessor;


    @Test
    public void getInventorySrc() throws Exception {
        Assert.assertNotNull(inventoryAccessor);

    }

    @Test
    public void setInventorySrc() throws Exception {
        Assert.assertNotNull(inventoryAccessor);

    }

    @Test
    public void loadInventory() throws Exception {
        Assert.assertNotNull(inventoryAccessor);
        List<Item> result = inventoryAccessor.loadInventory();
        Assert.assertNotNull(result);
        Assert.assertEquals(9, result.size());
    }

}
__author__ = "Ken"


class Statistics:
    mean = 0.0
    max = 0.0
    valid = False

    def __init__(self, mean, max, valid):
        self.mean = mean
        self.max = max
        self.valid = valid

from RollingWindow.Statistics import Statistics
from RollingWindow.IStatisticsGenerator import IStatisticsGenerator
import collections
import numpy as np


class StatisticGenerator(IStatisticsGenerator):
    maxWindow = 0
    valueBuffer = []
    count = 0
    rollingWindowStatistics = {}

    def __init__(self, streamdata, windowsizes):
        self.streamData = iter(streamdata)

        for eachSize in windowsizes:
            self.rollingWindowStatistics[eachSize] = Statistics(1, 1, False)
            self.maxWindow = np.max(windowsizes)
        self.valueBuffer = [1 for x in range(self.maxWindow + 1)]


    @property
    def hasNext(self):
        return next(self.streamData, None)

    def getNext(self, value):
        self.count += 1
        currentIndex = self.getcurrentindex
        self.valueBuffer[currentIndex] = value
        for eachWindowSize in self.rollingWindowStatistics.keys():
            if self.count >= eachWindowSize:
                if not self.rollingWindowStatistics[eachWindowSize].valid:
                    tmpmax = np.max(self.valueBuffer[1:eachWindowSize + 1])
                    tmpmean = np.mean(self.valueBuffer[1:eachWindowSize + 1])
                    self.rollingWindowStatistics[eachWindowSize].valid = True
                    self.rollingWindowStatistics[eachWindowSize].max = tmpmax
                    self.rollingWindowStatistics[eachWindowSize].mean = int(tmpmean)
                else:
                    tmpmax = max(self.rollingWindowStatistics[eachWindowSize].max, value)
                    self.rollingWindowStatistics[eachWindowSize].max = tmpmax
                    oldAvg = self.rollingWindowStatistics[eachWindowSize].mean
                    newAvg = self.approxiavg(value, eachWindowSize, oldAvg)
                    self.rollingWindowStatistics[eachWindowSize].mean = newAvg
        return self.rollingWindowStatistics


    def approxiavg(self,value,windowsize,oldAvg):
        newAvg = (oldAvg * (windowsize - 1) + value) / windowsize
        newRound = int(round(newAvg, 0))
        return newRound

    @property
    def getcurrentindex(self):
        if self.count <= self.maxWindow:
            return self.count
        else:
            tmp = self.count % self.maxWindow
            if tmp == 0:
                return self.maxWindow
            else:
                return tmp


class IStatisticsGenerator(object):
    def __init__(self, streamdata, windowsizes):
        pass

    @property
    def hasNext(self):
        raise Exception("Not Implemented")

    def getNext(self, value):
        raise Exception("Not Implemented")

    def approxiavg(self,value,windowsize,oldAvg):
        raise Exception("Not Implemented")

    @property
    def getcurrentindex(self):
        raise Exception("Not Implemented")
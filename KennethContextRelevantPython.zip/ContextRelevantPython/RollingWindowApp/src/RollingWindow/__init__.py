from RollingWindow.Statistics import  Statistics
from RollingWindow.StatisticsGenerator import StatisticGenerator

def main():
    print("Statistics Generator")
    inputstream = []
    for i in range(1,31):
        assert isinstance(i, object)
        inputstream.append(i)
    windowSize = [3,5,20]
    generator = StatisticGenerator(inputstream, windowSize)

    value = generator.hasNext
    while value is not None:
        rollDic = generator.getNext(value)
        output=[]
        for eachWindowSize in sorted(rollDic.keys()):
            if (rollDic[eachWindowSize].valid == False):
                output.append(None)
                output.append(None)
            else:
                output.append(rollDic[eachWindowSize].mean)
                output.append(rollDic[eachWindowSize].max)

        value = generator.hasNext
        print(output)

    print("\n")
    print("Completed Streaming")


if __name__ == "__main__":
    main()
